/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package json;

import java.util.ArrayList;
import java.util.List;

public class ListaMatriculas {

    private List<Matricula> matriculas = new ArrayList<>();

    public ListaMatriculas() {
    }

    public List<Matricula> getMatriculas() {
        return matriculas;
    }

    public void setAlumnos(List<Matricula> matriculas) {
        this.matriculas = matriculas;
    }

}
