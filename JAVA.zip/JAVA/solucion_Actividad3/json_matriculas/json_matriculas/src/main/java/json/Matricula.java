/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package json;

/**
 *
 * @author Anabel
 */
public class Matricula {

    private int id;
    private String nombre;
    private String curso;
    private float nota_final;
    private boolean matriculado;

    public Matricula(int id, String nombre, String curso, float nota_final, boolean matriculado) {
        this.id = id;
        this.nombre = nombre;
        this.curso = curso;
        this.nota_final = nota_final;
        this.matriculado = matriculado;
    }

    public Matricula() {
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public float getNota_final() {
        return nota_final;
    }

    public void setNota_final(float nota_final) {
        this.nota_final = nota_final;
    }

    public boolean isMatriculado() {
        return matriculado;
    }

    public void setMatriculado(boolean matriculado) {
        this.matriculado = matriculado;
    }

}
