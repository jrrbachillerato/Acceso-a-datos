/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package json;

import java.util.ArrayList;
import java.util.List;

public class ListaAlumnos {

    private List<Alumno> alumnos = new ArrayList<>();

     // Para el ArrayLista para ficheros JSON hay que definir un constructor por defecto, 
    public ListaAlumnos() {
    }

    //obtiene la lista de alumnos
    public List<Alumno> getAlumnos() {
        return alumnos;
    }

    //modifica la lista de alumnos
    public void setAlumnos(List<Alumno> alumnos) {
        this.alumnos = alumnos;
    }

}
