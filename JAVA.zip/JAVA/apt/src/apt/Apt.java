/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package apt;

/**
 *
 * @author Juan
 */
public class Apt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    // EXCEPTION
    
    // FileNotFoundException : Excepción lanzada cuando se intenta acceder a un archivo cuya ruta no existe o no se puede abrir.
    
//    try {
//        // Intentamos abrir un archivo que sabemos que no existe
//        File archivoFalso = new File("archivo_inexistente.txt");
//        Scanner sc = new Scanner(archivoFalso);
//
//    } catch (FileNotFoundException e) {
//        // Se captura el error y se muestra un mensaje controlado
//        System.out.println("¡ERROR! No se ha encontrado el archivo: " + e.getMessage());
//    }
    
    // InputMismatchException : Excepción lanzada cuando el formato del contenido leído no coincide con lo esperado o el archivo finaliza de forma inesperada.
    
    // El Scanner se abre dentro de los paréntesis y se cerrará automáticamente
//        try (Scanner sc = new Scanner(System.in)) {
//            
//            System.out.print("Introduce tu edad (debe ser un número): ");
//            int edad = sc.nextInt(); // Si escribes letras, se lanza InputMismatchException
//            
//            System.out.println("Has introducido la edad: " + edad);
//            
//        } catch (InputMismatchException e) {
//            // Se captura el desajuste de tipo
//            System.out.println("¡ERROR! Debes introducir un número entero válido.");
//        }
    
    // IOException : Se lanza de forma automática cuando ocurre un fallo o interrupción en las operaciones de Entrada/Salida (I/O) del sistema. Esto incluye problemas al interactuar con ficheros, directorios,etc.

    // -------JSON------ PROYECTO CON MAVEN 
    // Si trabajamos con JSON debemos usar ObjectMapper()
    // DEPENDENCIAS JSON
//    <dependencies>
//
//        <dependency>
//            <groupId>com.fasterxml.jackson.core</groupId>
//            <artifactId>jackson-databind</artifactId>
//            <version>2.20.0</version>
//        </dependency>
//
//    </dependencies>
    
    // Si da error al compilar, cambia la versión a la versión de Java, una vez hecho click en el proyecto y clean and build
//    <properties>
    //    <maven.compiler.source>AQUÍ</maven.compiler.source>
    //    <maven.compiler.target>AQUÍ</maven.compiler.target>
    //    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
//    </properties>
    
}

