/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package escritura;

public class Contacto {

    private String nombre;
    private String apellido;
    private String ciudad;
    private String grupo;
    private String telefono;

    public Contacto(String nombre, String apellido, String ciudad, String grupo, String telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.ciudad = ciudad;
        this.grupo = grupo;
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Contacto{" + "nombre=" + nombre + ", apellido=" + apellido + ", ciudad=" + ciudad + ", grupo=" + grupo + ", telefono=" + telefono + '}';
    }

  

    /**
     * Formatea los datos a CSV
     *
     * @return
     */
    /*public String toCSV() {
        return nombre + "#" + apellido + "#" + edad + '#';
    }*/
}
